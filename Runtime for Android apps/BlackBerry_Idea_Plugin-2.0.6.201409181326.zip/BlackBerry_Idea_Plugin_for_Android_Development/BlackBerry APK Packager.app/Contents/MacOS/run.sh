#!/bin/bash
here=$(dirname "$0")
"$here/../../../bin/blackberry-apkpackager" -gui